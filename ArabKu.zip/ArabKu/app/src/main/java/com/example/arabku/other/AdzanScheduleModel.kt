package com.example.arabku.other

import com.google.gson.annotations.SerializedName

data class AdzanScheduleModel(

	@field:SerializedName("statusmsg")
	val statusmsg: String,

	@field:SerializedName("data")
	val data: DataAdzan,

	@field:SerializedName("status")
	val status: String
)

data class DataAdzan(
	@field:SerializedName("isya")
	val isya: String,

	@field:SerializedName("dzuhur")
	val dzuhur: String,

	@field:SerializedName("subuh")
	val subuh: String,

	@field:SerializedName("dhuha")
	val dhuha: String,

	@field:SerializedName("tanggal")
	val tanggal: String,

	@field:SerializedName("ashar")
	val ashar: String,

	@field:SerializedName("maghrib")
	val maghrib: String
)

package com.example.arabku.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.arabku.R
import com.example.arabku.other.lightStatusBar

class SplashScreen : AppCompatActivity() {
    var start: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash_screen)
        supportActionBar?.hide()
        lightStatusBar(window)
        start = findViewById(R.id.button_splash)
        start?.setOnClickListener(View.OnClickListener {
            val intent = Intent(this@SplashScreen, MainActivity::class.java)
            startActivity(intent)
        })

    }
}
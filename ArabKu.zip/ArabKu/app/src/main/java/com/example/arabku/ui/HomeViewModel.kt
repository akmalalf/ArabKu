package com.example.arabku.ui

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.arabku.api.ApiConfig
import com.example.arabku.other.AdzanScheduleModel
import com.example.arabku.other.DataAdzan
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class HomeViewModel : ViewModel() {

    private val _adzan = MutableLiveData<DataAdzan>()
    val adzan: LiveData<DataAdzan> = _adzan

    fun getAdzan(token: String){
        val client = ApiConfig.getApiService().getAdzan("Bearer $token")
        client.enqueue(object : Callback<AdzanScheduleModel> {
            override fun onResponse(
                call: Call<AdzanScheduleModel>,
                response: Response<AdzanScheduleModel>
            ) {
                if (response.isSuccessful) {
                    _adzan.postValue(response.body()?.data)
                } else if (response.code() == 401){
                    Log.e(TAG, "Sesi Berakhir")
                } else {
                    Log.e(TAG, "Gagal")
                }
            }

            override fun onFailure(call: Call<AdzanScheduleModel>, t: Throwable) {
                Log.e(TAG, "onFailure: ${t.message}")
            }
        })
    }

    companion object {
        const val TAG = "LoginViewModel"
    }
}
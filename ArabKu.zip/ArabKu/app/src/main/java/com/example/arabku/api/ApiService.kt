package com.example.arabku.api

import com.example.arabku.other.AdzanScheduleModel
import retrofit2.Call
import retrofit2.http.*

interface ApiService {
    @GET("prayerTime")
    fun getAdzan(
        @Header("Authorization") token: String
    ): Call<AdzanScheduleModel>
}
package com.example.arabku.other

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.*

fun getDate(): String {

    val current = LocalDateTime.now()
    val formatter = DateTimeFormatter.ofPattern("EEEE/dd-MM-yyyy/HH:mm:ss/MMMM", Locale("in", "ID"))

    return current.format(formatter)
}
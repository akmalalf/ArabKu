package com.example.arabku.data

import android.content.Context
import android.content.SharedPreferences

class PrefManager(context: Context) {

    private var pref: SharedPreferences? = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getToken(): String? {
        return pref?.getString("token", "")
    }

    companion object {
        private const val PREFS_NAME = "user_pref"
    }
}
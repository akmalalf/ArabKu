package com.example.arabku.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import com.example.arabku.R
import com.example.arabku.other.lightStatusBar

class MainActivity : AppCompatActivity() {
    var scan: ImageButton? = null
    var gallery: ImageButton? = null
    var praying: ImageButton? = null
    var logout: CardView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        scan = findViewById(R.id.scan)
        gallery = findViewById(R.id.gallery)
        praying = findViewById(R.id.praying)
        logout = findViewById(R.id.cv_logout)
        supportActionBar?.hide()
        lightStatusBar(window)
        scan?.setOnClickListener(View.OnClickListener {
            val intent = Intent(this@MainActivity, CameraActivity::class.java)
            startActivity(intent)
        })
        gallery?.setOnClickListener(View.OnClickListener {
            val intent = Intent(this@MainActivity, GalleryActivity::class.java)
            startActivity(intent)
        })
        praying?.setOnClickListener(View.OnClickListener {
            val intent = Intent(this@MainActivity, PrayingActivity::class.java)
            startActivity(intent)
        })
        logout?.setOnClickListener(View.OnClickListener {
            val intent = Intent(this@MainActivity, SplashScreen::class.java)
            startActivity(intent)
        })
    }
}
package com.example.arabku.ui

import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat
import com.example.arabku.R
import com.example.arabku.databinding.ActivityPrayingBinding
import com.example.arabku.other.DataAdzan
import com.example.arabku.other.getDate
import com.example.arabku.other.lightStatusBar
import com.example.arabku.data.PrefManager

class PrayingActivity : AppCompatActivity() {

    private var _binding : ActivityPrayingBinding? = null
    private val binding get() = _binding!!
    
    private val adzanViewModel: HomeViewModel by viewModels()
    private lateinit var prefManager: PrefManager
    private val currentDate: List<String> = getDate().split("/")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        _binding = ActivityPrayingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()
        lightStatusBar(window)

        prefManager = PrefManager(this)
        val token = prefManager.getToken().toString()

        adzanViewModel.getAdzan(token)
        adzanViewModel.adzan.observe(this){
            val soon = adzanSoon(it).split(" ")

            binding.tvDateAdzan.text = it.tanggal
            binding.tvAdzanName.text = soon[0].trim()
            binding.tvAdzanSoon.text = soon[1].trim()
            binding.tvShubuhTime.text = it.subuh
            binding.tvDzuhurTime.text = it.dzuhur
            binding.tvAsharTime.text = it.ashar
            binding.tvMaghribTime.text = it.maghrib
            binding.tvIsyaTime.text = it.isya
        }

        val arrowBack : CardView = findViewById(R.id.cv_logout)
        arrowBack.setOnClickListener{
            onBackPressed()
        }
    }

    private fun adzanSoon(it: DataAdzan) : String {
        Log.e("Check", it.toString())
        val time = currentDate[2].split(":")
        var currentTime = "${time[0]}:${time[1]}"
        var shubuh = it.subuh
        var dzuhur = it.dzuhur
        var ashar = it.ashar
        var magrib = it.maghrib

        val re = Regex("[^A-Za-z0-9 ]")

        currentTime = re.replace(currentTime, "")
        shubuh = re.replace(shubuh, "")
        dzuhur = re.replace(dzuhur, "")
        ashar = re.replace(ashar, "")
        magrib = re.replace(magrib, "")

        if (currentTime.toInt() <= shubuh.toInt()){
            binding.clShubuh.setBackgroundColor(ContextCompat.getColor(this, R.color.red))
            return "Shubuh ${it.subuh}"
        } else if (currentTime.toInt() <= dzuhur.toInt()){
            binding.clDzuhur.setBackgroundColor(ContextCompat.getColor(this, R.color.red))
            return "Dzuhur ${it.dzuhur}"
        } else if (currentTime.toInt() <= ashar.toInt()){
            binding.clAshar.setBackgroundColor(ContextCompat.getColor(this, R.color.red))
            return "Ashar ${it.ashar}"
        } else if (currentTime.toInt() <= magrib.toInt()){
            binding.clMaghrib.setBackgroundColor(ContextCompat.getColor(this, R.color.red))
            return "Maghrib ${it.maghrib}"
        } else {
            binding.clIsya.setBackgroundColor(ContextCompat.getColor(this, R.color.red))
            return "Isya ${it.isya}"
        }
    }
}